package examLog;

public class Person {

	protected int age;
	
	public void setAge(int n) {
		this.age = n;
	}
	
	public void sayHello() {
		System.out.println("Hello");
	}
	
}
