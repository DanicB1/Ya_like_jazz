package examLog;

public class Teacher extends Person {
	
	private String subject;

	public void Explain() {
		System.out.println("Explanation begins");
	}
	
}
