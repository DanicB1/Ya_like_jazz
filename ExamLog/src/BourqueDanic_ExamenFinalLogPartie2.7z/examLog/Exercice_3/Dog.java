package examLog;

public class Dog implements Animal {

	@Override
	public void shout() {
		System.out.println("Wouf");
	}
	
}
