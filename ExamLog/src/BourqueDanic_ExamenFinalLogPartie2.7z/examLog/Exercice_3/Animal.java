package examLog;

public interface Animal {

	public void shout();
	
}
