package examLog;

public class Cat implements Animal {

	@Override
	public void shout() {
		System.out.println("Miaou");
	}

}
